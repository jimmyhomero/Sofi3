package imageclient;

public class ImageClient {

    public static void main(String[] args) {
        Cliente c = new Cliente();
    }
}
