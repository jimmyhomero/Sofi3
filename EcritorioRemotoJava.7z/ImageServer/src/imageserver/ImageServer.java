package imageserver;

public class ImageServer {

    public static void main(String[] args) {
        Servidor s = new Servidor();
    }
}
